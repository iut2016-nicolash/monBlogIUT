<?php
/* Smarty version 3.1.30, created on 2016-12-17 13:54:42
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\supprimer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58553592c99e15_03467849',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '088b623723c6a9eaa5e510c3d9deb4ddedc97bf2' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\supprimer.tpl',
      1 => 1481911767,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58553592c99e15_03467849 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h2><?php echo $_smarty_tpl->tpl_vars['titre']->value;?>
</h2>
<img src="img/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
.jpg" width="600px" alt="photo"/>

<div>
    <p id="texte_confirmer_supprimer">Voulez-vous vraiment supprimer l'article ainsi que tous les commentaires ?</p>

    <form action="index.php?oui_YyxSx0Ae2k=<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
" method="post" enctype="multipart/form-data" id="bouton_confirmer_supprimer" name="form_article">
        <div class="bouton_confirmer_supprimer">
            <input type="submit" name="Oui" value="Oui" class="btn btn-large btn-primary">
        </div>
    </form>

    <form action="index.php" method="post" enctype="multipart/form-data" id="bouton_confirmer_supprimer" name="form_article">
        <div class="bouton_confirmer_supprimer">
            <input type="submit" name="Non" value="Non" class="btn btn-large btn-primary">
        </div>
    </form>

    <div class="clear"></div>
</div><?php }
}
