<?php
/* Smarty version 3.1.30, created on 2016-12-17 16:05:00
  from "C:\wamp\www\iut2016_nicolas_herbez_local\templates\bouton_annuler.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5855541c800367_92319922',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '37d52eb1084b41ad4f824b8600e68e5abd283289' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez_local\\templates\\bouton_annuler.tpl',
      1 => 1481902273,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5855541c800367_92319922 (Smarty_Internal_Template $_smarty_tpl) {
?>
<form class="span12" action="index.php" method="post" id="bouton_annuler">

    <input type="submit" value="Annuler" name="boutonAnnuler" class="btn btn-medium btn-primary"/>

</form><?php }
}
