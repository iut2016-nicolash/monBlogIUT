<?php
/* Smarty version 3.1.30, created on 2016-12-17 09:50:12
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\commentaires.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5854fc44738485_88161205',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '136387b28702916d4906f1e19c9089651096ae10' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\commentaires.tpl',
      1 => 1481915153,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5854fc44738485_88161205 (Smarty_Internal_Template $_smarty_tpl) {
?>
<form id="cadre_commentaire">
    <p id="commentaire_legend"><?php echo $_smarty_tpl->tpl_vars['prenom']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['nom']->value;?>
</p>
    <p><?php echo $_smarty_tpl->tpl_vars['commentaire']->value;?>
</p>

    <p id="commentaires_date"><em><u>Publié le : <?php echo $_smarty_tpl->tpl_vars['date']->value;?>
</u></em></p>
</form>
<?php }
}
