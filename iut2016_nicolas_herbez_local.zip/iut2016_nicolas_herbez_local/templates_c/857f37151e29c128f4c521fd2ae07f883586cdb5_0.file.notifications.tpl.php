<?php
/* Smarty version 3.1.30, created on 2016-12-17 09:23:04
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\notifications.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5854f5e8844cc4_49973534',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '857f37151e29c128f4c521fd2ae07f883586cdb5' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\notifications.tpl',
      1 => 1481622222,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5854f5e8844cc4_49973534 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="span12">
    <div class="alert alert-warning" role="alert"><?php echo $_smarty_tpl->tpl_vars['session']->value;?>
</div>
</div><?php }
}
