<?php
/* Smarty version 3.1.30, created on 2016-12-17 16:04:57
  from "C:\wamp\www\iut2016_nicolas_herbez_local\templates\notifications.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58555419799116_17745285',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e47cd1bcf0aab4d74a318c545932b0d8c202bf57' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez_local\\templates\\notifications.tpl',
      1 => 1481622222,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_58555419799116_17745285 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="span12">
    <div class="alert alert-warning" role="alert"><?php echo $_smarty_tpl->tpl_vars['session']->value;?>
</div>
</div><?php }
}
