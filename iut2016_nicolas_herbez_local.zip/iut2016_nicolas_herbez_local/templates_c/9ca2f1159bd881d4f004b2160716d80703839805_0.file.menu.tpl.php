<?php
/* Smarty version 3.1.30, created on 2016-12-17 09:23:04
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\menu.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5854f5e8844cc0_01099549',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9ca2f1159bd881d4f004b2160716d80703839805' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\menu.tpl',
      1 => 1481960486,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5854f5e8844cc0_01099549 (Smarty_Internal_Template $_smarty_tpl) {
?>
<nav class="span4">
    <h3>Menu</h3>

    <form action="index.php" method="get" enctype="multipart/form-data" id="form_recherche">

        <div class="clearfix">
            <div class="input"><input type="text" name="recherche" id="recherche" placeholder="Votre recherche ..." required></div>
        </div>

        <div class="form-inline">
            <input type="submit" name="" value="Rechercher" class="btn btn-mini btn-primary">
        </div>
    </form>

    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="index.php?rediger=">Rédiger un article</a></li>
        <?php echo $_smarty_tpl->tpl_vars['lien_articles_non_publie']->value;?>

        <li><a href="<?php echo $_smarty_tpl->tpl_vars['redirection']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['connexion']->value;?>
</a></li>
        
    </ul>

</nav>
<div class="span8">
<?php }
}
