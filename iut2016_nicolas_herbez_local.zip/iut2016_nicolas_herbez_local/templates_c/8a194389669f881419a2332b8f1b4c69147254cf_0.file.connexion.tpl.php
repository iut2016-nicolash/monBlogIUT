<?php
/* Smarty version 3.1.30, created on 2016-12-17 16:05:00
  from "C:\wamp\www\iut2016_nicolas_herbez_local\templates\connexion.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5855541c7c3468_06731372',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8a194389669f881419a2332b8f1b4c69147254cf' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez_local\\templates\\connexion.tpl',
      1 => 1481909389,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5855541c7c3468_06731372 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="span12">

    <form action="nouveau_compte.php" method="post" id="nouveau_compte_bouton">

        <input type="submit" value="Nouveau compte" name="boutonNouveau_compte" class="btn btn-medium btn-primary"/>

    </form>

    <form action="connexion.php" method="post" id="connexion">

        <!-- l'étiquette login -->
        <label for="email">Email : </label>

        <!-- le champ , type text, "required" rend le champ obligatoire -->
        <input type="text" name="email" placeholder="Rentrer votre email" size="40" maxlength="50" id="email" required/>
        <br>
        <br>

        <!-- l'étiquette mdp -->
        <label for="mdp">Mot de passe : </label>

        <!-- le champ, type password cache le mdp -->
        <input type="password" name="mdp" placeholder="Rentrer votre mdp" size="40" maxlength="50" id="mdp" required/>
        <br>
        <br>

        <div id="echec_connexion"><?php echo $_smarty_tpl->tpl_vars['echec_connexion']->value;?>
</div>
        <input type="submit" value="Connexion" name="boutonValiderConnexion" class="btn btn-medium btn-primary"/>

    </form>

</div>
<?php }
}
