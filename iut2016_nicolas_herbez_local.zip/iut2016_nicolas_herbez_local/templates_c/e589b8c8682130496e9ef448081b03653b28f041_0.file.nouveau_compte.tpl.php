<?php
/* Smarty version 3.1.30, created on 2016-12-17 16:05:49
  from "C:\wamp\www\iut2016_nicolas_herbez_local\templates\nouveau_compte.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5855544dd3b9d4_60896707',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e589b8c8682130496e9ef448081b03653b28f041' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez_local\\templates\\nouveau_compte.tpl',
      1 => 1481909437,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5855544dd3b9d4_60896707 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="span12">
    <form action="nouveau_compte.php" method="post" id="nouveau_compte_form">

        <!-- l'étiquette NOM -->
        <label for="nom">NOM :</label>

        <!-- le champ , type text, "required" rend le champ obligatoire -->
        <input type="text" name="nom" placeholder="Rentrer votre NOM" value="<?php echo $_smarty_tpl->tpl_vars['nom']->value;?>
" size="40" maxlength="50" id="nom" required/>
        <br />
        <br />

        <!-- l'étiquette Prénom -->
        <label for="prenom">Prénom :</label>

        <input type="text" name="prenom" placeholder="Rentrer votre Prénom" value="<?php echo $_smarty_tpl->tpl_vars['prenom']->value;?>
" size="40" maxlength="50" id="prenom" required/>
        <br />
        <br />

        <!-- l'étiquette email -->
        <label for="email"><?php echo $_smarty_tpl->tpl_vars['alert_email']->value;?>
</label>

        <!-- le champ , type text, "required" rend le champ obligatoire -->
        <input type="email" name="email" placeholder="Rentrer votre email" value="<?php echo $_smarty_tpl->tpl_vars['email']->value;?>
" size="40" maxlength="50" id="email" required/>
        <br />
        <br />

        <!-- l'étiquette mdp -->
        <label for="mdp">Mot de passe :</label>

        <!-- le champ, type password cache le mdp -->
        <input type="password" name="mdp" placeholder="Rentrer votre mdp" value="<?php echo $_smarty_tpl->tpl_vars['mdp']->value;?>
" size="40" maxlength="50" id="mdp" required/>
        <br />
        <br />

        <input type="submit" value="Valider" name="boutonValider" class="btn btn-medium btn-primary"/>

    </form>
</div>
<?php }
}
