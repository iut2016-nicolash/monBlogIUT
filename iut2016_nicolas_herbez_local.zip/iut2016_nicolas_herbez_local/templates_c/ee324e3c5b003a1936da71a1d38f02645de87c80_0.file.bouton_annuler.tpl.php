<?php
/* Smarty version 3.1.30, created on 2016-12-17 09:23:03
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\bouton_annuler.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5854f5e73884a4_75235612',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ee324e3c5b003a1936da71a1d38f02645de87c80' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\bouton_annuler.tpl',
      1 => 1481902273,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5854f5e73884a4_75235612 (Smarty_Internal_Template $_smarty_tpl) {
?>
<form class="span12" action="index.php" method="post" id="bouton_annuler">

    <input type="submit" value="Annuler" name="boutonAnnuler" class="btn btn-medium btn-primary"/>

</form><?php }
}
