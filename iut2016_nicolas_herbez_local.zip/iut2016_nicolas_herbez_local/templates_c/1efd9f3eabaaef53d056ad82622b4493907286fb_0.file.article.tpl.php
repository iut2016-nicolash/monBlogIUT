<?php
/* Smarty version 3.1.30, created on 2016-12-17 09:30:16
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\article.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5854f79855daa5_89071561',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1efd9f3eabaaef53d056ad82622b4493907286fb' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\article.tpl',
      1 => 1481963412,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5854f79855daa5_89071561 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div class="span12">
    <form class="form_article" action="article.php" method="post" enctype="multipart/form-data" name="form_article">

        <div class="clearfix">
            <label id="label_titre">Titre</label>
            <div class="input"><textarea name="titre" id="titre_article" cols="30" rows="1" required><?php echo $_smarty_tpl->tpl_vars['titre']->value;?>
</textarea></div>
        </div>
        <br>

        <div class="clearfix">
            <label id="label_texte">Texte</label>
            <div class="input"><textarea name="texte" id="texte_article" cols="200" rows="10"><?php echo $_smarty_tpl->tpl_vars['texte']->value;?>
</textarea></div>
        </div>
        <br>

        <div class="clearfix">
            <label id="label_image">Image</label>
            <div class="input"><input type="file" name="image" id="image_article" value="" required></div>
        </div>
        <br>
        <br>

        <div class="clearfix">
            <label id="label_publie">Publié </label>
            <div class="input"><input type="checkbox" name="publie" id="checkbox_article" value="on"></div>
        </div>
        <br>
        <br>

        <div class="form_actions_article">
            <input type="submit" name=<?php echo $_smarty_tpl->tpl_vars['bouton']->value;?>
 value=<?php echo $_smarty_tpl->tpl_vars['bouton']->value;?>
 class="btn btn-medium btn-primary" id="bouton_article">
        </div>

        <input type="hidden" name="id_article" value=<?php echo $_smarty_tpl->tpl_vars['id_article']->value;?>
>
        <input type="hidden" name="id_utilisateur" value=<?php echo $_smarty_tpl->tpl_vars['id_utilisateur']->value;?>
>

    </form>
</div>
<?php }
}
