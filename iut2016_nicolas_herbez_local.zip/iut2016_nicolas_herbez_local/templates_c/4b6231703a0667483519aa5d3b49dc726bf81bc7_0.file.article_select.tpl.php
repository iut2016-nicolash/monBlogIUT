<?php
/* Smarty version 3.1.30, created on 2016-12-17 09:50:04
  from "C:\wamp\www\iut2016_nicolas_herbez\templates\article_select.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5854fc3c0bff94_93851210',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4b6231703a0667483519aa5d3b49dc726bf81bc7' => 
    array (
      0 => 'C:\\wamp\\www\\iut2016_nicolas_herbez\\templates\\article_select.tpl',
      1 => 1481824376,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5854fc3c0bff94_93851210 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h2><?php echo $_smarty_tpl->tpl_vars['titre']->value;?>
</h2>
<div id="cadre_article">
    <div id="signature">
        <?php echo $_smarty_tpl->tpl_vars['prenom']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['nom']->value;?>

    </div>
    <img src="img/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
.jpg" width="600px" alt="photo"/>
    <p id="texte"><?php echo $_smarty_tpl->tpl_vars['texte']->value;?>
</p>
</div>
<br>
<h4>Commentaires</h4>
<?php }
}
