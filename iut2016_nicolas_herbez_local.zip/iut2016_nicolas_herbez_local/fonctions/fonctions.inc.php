<?php

function returnIndex($nP, $nAPP) {
    //calculer l'index de départ
    return ceil(($nP - 1) * $nAPP); //ceil retourne l'entier supérieur (ex: 13/2=7)
}
